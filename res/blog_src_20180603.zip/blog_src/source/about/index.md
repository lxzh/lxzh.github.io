---
title: 关于
date: 2016-05-24 22:38:59
comments: false
---
### 关于我
雷进锋，三年EE工程师进化为程序猿

曾经因为好玩爱上了`写代码`与`瞎折腾`；

前三年迫于工作压力只好写代码`写工具`换点业绩；

如今又被迫走上了一条所谓的`艺术创作`的不归路

写代码的两种追求：
其一弥补懒惰
其二创作艺术

热爱编程

但厌恶这个行业

但愿有一天

能仅因为兴趣而写代码

![小小的梦想](http://o8ydbqznc.bkt.clouddn.com/blog/little_dream.jpg)


### 关于博客
2016年某月`SAE`开始收费，博客被爬虫狂爬致豆豆不够用，终无力支持`SAE`，遂迁移至`Github Pages`

### 联系我
github : [ljf1239848066](https://github.com/ljf1239848066)
email : 1239848066@qq.com
简书 : [龙心之火](http://www.jianshu.com/u/7648c603f740)



