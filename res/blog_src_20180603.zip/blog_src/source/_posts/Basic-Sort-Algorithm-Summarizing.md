---
title: 基础排序算法——汇总
date: 2014-04-19 16:11:01
tags: data structure
---
&ensp; &ensp; &ensp; 本文集中汇总`冒泡排序`、`插入排序`、`对半插入排序`三种算法，并分别用`C++`、`C#`、`Java`三种语言实现。
<!--more-->

# 冒泡排序：

## C++ Code:

```cpp
void BubbleSort(int* a,int n)  
{  
    int tmp;  
    for(int i=n;i>=1 ;i--)  
    {  
        for (int j = 0; j < i - 1; j++)  
        {  
            if (a[j] > a[j + 1]) //降序改为"" 
            {  
                tmp = a[j];  
                a[j] = a[j + 1];  
                a[j + 1] = tmp;  
            }  
        }  
    }  
} 
```
## C# Code

```cs
public void BubbleSort(int []array)  
{  
    int temp;  
    int count = array.Length;  
    for(int i=count;i>=1 ;i--)  
    {  
        for (int j = 0; j < i - 1; j++)  
        {  
            if (array[j] > array[j + 1]) //降序改为"<" 
            {  
                temp = array[j];  
                array[j] = array[j + 1];  
                array[j + 1] = temp;  
            }  
        }  
    }  
}
```

```cs
public void BubbleSort(List<Int32> array)
{
    int temp;
    int count = array.Count;
    for (int i = count; i >= 1; i--)
    {
        for (int j = 0; j < i - 1; j++)
        {
            if (array[j] > array[j + 1])//降序改为"<" 
            {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
}
```

## Java Code

```java
public void bubbleSort(int []array)  
{  
    int temp;  
    int count = array.length;  
    for(int i=count;i>=1 ;i--)  
    {  
        for (int j = 0; j < i - 1; j++)  
        {  
            if (array[j] > array[j + 1])//降序改为"<"   
            {  
                temp = array[j];  
                array[j] = array[j + 1];  
                array[j + 1] = temp;  
            }  
        }  
    }  
}
```

```java
public void bubbleSort(List<Integer>array)  
{  
    int temp;  
    int count = array.size();  
    for(int i=count;i>=1 ;i--)  
    {  
        for (int j = 0; j < i - 1; j++)  
        {  
            if (array.get(j) > array.get(j + 1)) //降序改为"<"  
            {  
                temp = array.get(j);  
                array.set(j, array.get(j + 1));  
                array.set(j + 1,temp);  
            }  
        }  
    }  
}
```
# 插入排序

## C++ Code
```cpp
void InsertSort(int* a,int n)
{
	int j = 0,temp;
	for (int i = 1; i < n; i++)
	{
		temp = a[i];
		j = i;
		while (j > 0 && a[j - 1] >= temp)
		{
			a[j] = a[j - 1];
			j -= 1;
		}
		a[j] = temp;
	}
}
```
## C# Code

```cs
public void InsertSort(int[] array)  
{    
    int j = 0,temp;    
    int count = array.Length;    
    for (int i = 1; i < count; i++)    
    {    
        temp = array[i];    
        j = i;    
        while (j > 0 && array[j - 1] >= temp)    
        {    
            array[j] = array[j - 1];    
            j -= 1;    
        }    
        array[j] = temp;    
        PrintArray(array);    
    }    
}  
```
## Java Code

```java
public void InsertSort(int[] array)  
{    
    int j = 0,temp;    
    int count = array.length;    
    for (int i = 1; i < count; i++)    
    {    
        temp = array[i];    
        j = i;    
        while (j > 0 && array[j - 1] >= temp)    
        {    
            array[j] = array[j - 1];    
            j -= 1;    
        }    
        array[j] = temp;   
    }    
} 
```

```java
public void InsertSort(List<Integer> array)  
{    
    int j = 0,temp;    
    int count = array.size();    
    for (int i = 1; i < count; i++)    
    {    
        temp = array.get(i);    
        j = i;    
        while (j > 0 && array.get(j - 1) >= temp)    
        {    
        	array.set(j, array.get(j-1));    
            j -= 1;    
        }    
        array.set(j, temp);   
    }    
}
```
# 对半插入排序算法
## C++ Code 

```cpp
void HalfInsertSort(int* a,int n)
{
	int j = 0, temp, low, high, mid;
	for (int i = 1; i < n; i++)
	{
		temp = a[i];
		low = 0;
		high = i - 1;
		while (low <= high)
		{
			mid = (low + high) / 2;
			if (temp < a[mid]) high = mid - 1;
			else low = mid + 1;
		}
		for (j = i - 1; j >= low; j--) a[j + 1] = a[j];
		a[low] = temp;
	}
}
```
## C# Code

```cs
public void HalfInsertSort(int[] array)
{
    int j = 0, temp, low, high, mid;
    int count = array.Length;
    for (int i = 1; i < count; i++)
    {
        temp = array[i];
        low = 0;
        high = i - 1;
        while (low <= high)
        {
            mid = (low + high) / 2;
            if (temp < array[mid]) high = mid - 1;
            else low = mid + 1;
        }
        for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
        array[low] = temp;
    }
}
```
## Java Code

```java
public void HalfInsertSort(int[] array)
{
    int j = 0, temp, low, high, mid;
    int count = array.length;
    for (int i = 1; i < count; i++)
    {
        temp = array[i];
        low = 0;
        high = i - 1;
        while (low <= high)
        {
            mid = (low + high) / 2;
            if (temp < array[mid]) high = mid - 1;
            else low = mid + 1;
        }
        for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
        array[low] = temp;
    }
}
```

```java
public void HalfInsertSort(List<Integer> array)
{
    int j = 0, temp, low, high, mid;
    int count = array.size();
    for (int i = 1; i < count; i++)
    {
        temp = array.get(i);
        low = 0;
        high = i - 1;
        while (low <= high)
        {
            mid = (low + high) / 2;
            if (temp < array.get(mid)) high = mid - 1;
            else low = mid + 1;
        }
        for (j = i - 1; j >= low; j--) array.set(j+1,array.get(j));
        array.set(low, temp);
    }
}
```
<span><a>反馈请点击:</a><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&amp;email=lKWmp62soKykoqLU5eW69-v5" style="text-decoration:none"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png" alt="" /></a></span>


