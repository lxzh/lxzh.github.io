---
title: 查找算法
date: 2014-04-19 16:58:51
tags: data structure
---
&ensp; &ensp; &ensp; 本文集中了两种查找算法:`顺序查找算法`与`二分查找算法`，其中二分查找算法又有两种实现方式，分别为**递归查找**与**迭代查找**。
<!--more-->
# 顺序查找算法
## C++ Code
```cpp
int OrderFind(int* a,int n, int x)
{
	for (int i = 0; i < n; i++)
	{
		if (a[i] == x)
			return i;
	}
	return -1;
}
```
## C# Code

```cs
public int OrderFind(int[] array, int x)
{
    int count = array.Length;
    for (int i = 0; i < count; i++)
    {
        if (array[i] == x)
            return i;
    }
    return -1;
}
```
## Java Code
```java
public int OrderFind(int[] array, int x)
{
    int count = array.length;
    for (int i = 0; i < count; i++)
    {
        if (array[i] == x)
            return i;
    }
    return -1;
}
```
# 二分查找(对半)算法
## C++ Code

```cpp
//二分查找递归算法
int BinarySearch(int* a, int x, int low, int high)
{
	int mid = -1;
	if (low <= high)
	{
		if (a[mid] < x) mid = BinarySearch(a, x, mid + 1, high);
		else if (x < a[mid]) mid = BinarySearch(a, x, low, mid - 1);
	}
	return mid;
}
```

```cpp
//二分查找迭代算法
int BinarySearch(int* a,int n, int x)
{
	int low = 0, high = n - 1,mid=-1;
	while (low <= high)
	{
		mid = (low + high) / 2;
		if (x < a[mid]) high = mid - 1;
		else if (x > a[mid]) low = mid + 1;
		else return mid;
	}
	if (a[mid] != x) mid = -1;
	return mid;
}
```
## C# Code
```cs
//二分查找递归算法
public int BinarySearch(int[] array, int x, int low, int high)
{
    int mid = -1;
    if (low <= high)
    {
        if (array[mid] < x) mid = BinarySearch(array, x, mid + 1, high);
        else if (x < array[mid]) mid = BinarySearch(array, x, low, mid - 1);
    }
    return mid;
}
```
```cs
//二分查找迭代算法
public int BinarySearch(int[] array, int x)
{
    int count = array.Length;
    int low = 0, high = count - 1,mid=-1;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (x < array[mid]) high = mid - 1;
        else if (x > array[mid]) low = mid + 1;
        else return mid;
    }
    if (array[mid] != x) mid = -1;
    return mid;
}
```
## Java Code

```java
//二分查找递归算法
public int BinarySearch(int[] array, int x, int low, int high)
{
    int mid = -1;
    if (low <= high)
    {
        if (array[mid] < x) mid = BinarySearch(array, x, mid + 1, high);
        else if (x < array[mid]) mid = BinarySearch(array, x, low, mid - 1);
    }
    return mid;
}
```

```java
//二分查找迭代算法
public int BinarySearch(int[] array, int x)
{
    int count = array.length;
    int low = 0, high = count - 1,mid=-1;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (x < array[mid]) high = mid - 1;
        else if (x > array[mid]) low = mid + 1;
        else return mid;
    }
    if (array[mid] != x) mid = -1;
    return mid;
}
```

<span><a>反馈请点击:</a><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&amp;email=lKWmp62soKykoqLU5eW69-v5" style="text-decoration:none"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png" alt="" /></a></span>


