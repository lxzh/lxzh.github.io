---
title: Extjs导出excel数据
date: 2015-04-18 18:49:48
tags: Extjs
---

环境：前台：`Extjs`；后台`hibernate+struct`

需求：前台查询结果分页显示，导出到`excel`时需要导出**所有符合查询条件**的记录。
<!--more-->
前台：

```js
var panel = Ext.getCmp('qRINFPanel');
var form = panel.getForm();
var params = grid.getStore().baseParams;
params['filename']='projects.xls';
params['q_pDomain'] = getAgentDomain();
form.standardSubmit=true;
var paramstr='';
for(var s in params){
	paramstr+=s+"="+params[s]+"&";
}
var reg=new RegExp('undefined','g'); //创建正则RegExp对象  
paramstr=paramstr.replace(reg,'');  //去掉未赋值的参数默认值
form.url='exportProjects.action?'+paramstr;
form.method='POST';
form.submit();
```
`qRINFPanel`为`panel`的`id`，`params`里面还有其他参数，这个是存储前台查询用的参数对象。

前台将查询参数转换为`json`格式放在`url`中（不要用`Extjs.encode`方法，很坑，后台`request.getParameter`获取不到），后台拿到查询参数后，从数据库查询记录，然后生成`excel`，以流的形式输出到前台下载即可。

后台代码：

```java
public void exportProjects() {
	boolean status = false;
	String rtnMsg = "项目信息导出失败";
	ServletOutputStream os = null;
	System.out.println("导出检索到的项目信息");

	fileName = request.getParameter("filename");
	List<ProjectCell> projectList = getProjects("", "");
	try {
		response.reset();
		response.setContentType("application/msexcel;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		response.addHeader("Content-Disposition", "attachment;filename=\""
				+ new String(fileName.getBytes("UTF-8"), "ISO8859_1")
				+ "\"");
		os = response.getOutputStream();

		// 判断格式
		String type = getPostfix(fileName);
		System.out.println(type);
		if (type.equals("")) {
			status = false;
			rtnMsg = "未知的文件格式";
		} else if (type.equalsIgnoreCase("xls")) {
			writeXLS(os, projectList);
			status = true;
			rtnMsg = "项目信息导出成功";
			os.flush();
			os.close();
			// rtnMsg=file.getAbsolutePath().replace("\\", "/");
		} else if (type.equalsIgnoreCase("xlsx")) {
			writeXLSX(os, projectList);
			status = true;
			rtnMsg = "项目信息导出成功";
			os.flush();
			os.close();
		} else {
			status = false;
			rtnMsg = "不支持的文件格式:" + type;
		}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
		status = false;
		rtnMsg = "服务器文件不存在，请联系管理员";
	} catch (IOException e) {
		e.printStackTrace();
		status = false;
		rtnMsg = "服务器文件操作IO异常，请联系管理员";
	} catch (NullPointerException e) {
		e.printStackTrace();
		status = false;
		rtnMsg = "空指针异常，请联系管理员";
	}

	/**
	 * 获取操作结果
	 */
	String result = "{success:" + status + ",rtnMsg:'" + rtnMsg + "'}";
	System.out.println(result);
}
```
其中，`getProjects("","") ` 方法是从`request`中取参数进行查询，返回`List`数组

