---
title: 优雅的过滤广告
date: 2018-03-30 22:02:44
tags: Little skill
---

[TOC]

# 广告过滤

最近在浏览网页的时候，感觉有些网站的广告真的很烦，一不好看影响视觉，二总在切图吸引注意力，三有些广告有点少儿不宜，于是琢磨该如何过滤广告呢？

起初这个想法源自于公司办公的时候。由于公司访问外网必须要配置代理，而在配置代理的地方有个高级设置，里面可以通过精确/模糊匹配的方式过滤一些网址，本来这个功能平时一直用于过滤公司内部的一些服务器或内部网址等，避免也走代理导致无法访问。

<!-- more-->

既然这功能能够过滤内网不走代理，那么是不是也可以过滤广告不走代理呢？

抱着试一试的心态，凭借着一点点网页调试的技能，抓到一个广告的网址(后面介绍如何抓广告网址)，将它的host地址塞到代理过滤列表里，保存，然后刷新网页，广告蹦不出来啦~嘚瑟～(￣▽￣～)(～￣▽￣)～嘚瑟~
见下图：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1522419990947.png" width="940"/>

图1为本地代理设置入口，对于Windows系统一般很多浏览器的代理都可以配置使用Internet Explorer的代理，因此这里配置可以多其他浏览器都生效。图2中勾选"跳过本地地址的代理服务器"，点击"高级"按钮进入图3，在"例外情况"输入框中填入需要过滤的广告网址host。
>注：以上方法对于公司通过代理上外网有效。

于是，又去几个有广告的页面，分别抓到他们的广告网址纷纷丢到过滤列表了，QND，有的网页同一个广告挂了三四个，哥全给你毙了，顿时网页清净多了~


# 抓取网页中的广告链接

以下针对Chrome浏览器简单介绍，其他浏览器类似：

如图，CSDN博客左侧中与右下角的广告是我们本次的目标：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1522422416692.png" width="1500"/>

在 菜单》工具》开发者工具 打开`开发人员工具`辅助面板，依次展开里面的`body`以及多级`div`标签，在展开的过程中通过在不同的div移动，观察上面网页上浅蓝色蒙版当前定位，刚好盖在广告上时就说嘛找到了，从而快速找到是那个div下面有广告链接，如下图：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1522422659640.png" width="1500"/>
高亮的`div`即是我们要找的位置，注意到里面有个`src=//cee1.iteye.com/lgyyovfyh.js`的链接，OK，其中的`cee1.iteye.com`就是广告链接的`host`地址，依次类推，本页面右下角的广告host为`pos.baidu.com`。
不过，本页面的作者比较厚道，代码中直接有注释`<!--投放代码-->`、`<!--右下角弹窗广告-->`，有助于快速找到广告的标签。

通过以上方式配合公司代理过滤，就可以达到过滤广告的目的，以后遇到一个抓一个，从此网页浏览一片清净~


# 非公司网络如何过滤广告呢

但是回到家，不需要公司代理，该如何过滤广告呢？用第三方软件、插件？难选！效果不佳！不靠谱！！！不靠谱！！！不靠谱！！！（`重要的事说三遍`）

搞一个代理服务器？太麻烦！

那该怎么办呢？


## 改 hosts 翻墙（Idea借鉴）

想到以前没有代理又想用google的一点小技能：`改hosts访问google`，方法这里不介绍了，读者可自行网上搜一下。

这里copy一下`hosts的原理`(源于百度百科)：

>hosts是一个没有扩展名的系统文件，可以用记事本等工具打开，其作用就是将一些常用的网址域名与其对应的IP地址建立一个关联“数据库”，当用户在浏览器中输入一个需要登录的网址时，系统会`首先自动从Hosts文件中寻找对应的IP地址`，一旦找到，系统会立即打开对应网页，如果没有找到，则系统会再将网址提交DNS域名解析服务器进行IP地址的解析。
需要注意的是，Hosts文件配置的映射是`静态的`，如果网络上的计算机更改了请及时更新IP地址，否则将不能访问。

概括一下就是手动给浏览器一个`域名—IP`的配置表，让它从配置中快速找到域名对应的IP地址，而不是去DNS服务器查找，从而直接访问目标服务器。

## 改 hosts屏蔽广告

既然我们可以通过改hosts`指引`浏览器去访问一个网站，那么也可以`"误导"`它，_告诉它一个错误的IP，让它`找不到广告服务器`，从而实现`屏蔽广告`的目的_。

## 选误导IP

那么该告诉浏览器什么地址比较合适呢，这个就比较简单了，随便选一个不常用的IP，ping一下，ping不通就可以了，比如：1.1.1.1，2.2.2.2等等，随便啦！

## 配置hosts

将上文中介绍的找到的广告host，配合选好的`错误的IP`地址填入系统hosts配置文件，格式如下，追加到hosts配置文件末尾，保存即可(`可能需要管理员权限`)。

```
#百度
127.0.0.1 cpro.baidu.com
127.0.0.1 pos.baidu.com
#ITeye
127.0.0.1 cee1.iteye.com
# google
0.0.0.0 pagead2.googlesyndication.com
```

如果有部分广告仍旧冒出来了，可尝试更换IP试试，本人试了0.0.0.0对于有些广告不管用，有些管用，不知为啥。


# 后记

一点小技巧，需要长期积累收集广告链接。另外对于一些应然软件中的广告，可能就需要一点网络抓包的技能了，这里就不展开了，祝上网愉快~


# 附：

## 各系统hosts路径：
Windows：`C:\Windows\System32\drivers\etc\hosts`
Linux：`/etc/hosts`
macOS：`/etc/hosts`

## 网上搜集的一些广告链接：

```
#AD Block Start

#百度
127.0.0.1 cpro.baidu.com
127.0.0.1 pos.baidu.com

#ITeye
127.0.0.1 cee1.iteye.com

#优酷
0.0.0.0 valb.atm.youku.com
0.0.0.0 vid.atm.youku.com
0.0.0.0 valo.atm.youku.com
0.0.0.0 valf.atm.youku.com
0.0.0.0 walp.atm.youku.com
0.0.0.0 static.atm.youku.com
0.0.0.0 images.sohu.com
127.0.0.1 atm.youku.com
127.0.0.1 Fvid.atm.youku.com
127.0.0.1 html.atm.youku.com
127.0.0.1 static.atm.youku.com
127.0.0.1 valb.atm.youku.com
127.0.0.1 valc.atm.youku.com
127.0.0.1 valf.atm.youku.com
127.0.0.1 valo.atm.youku.com
127.0.0.1 valp.atm.youku.com
127.0.0.1 lstat.youku.com
127.0.0.1 speed.lstat.youku.com
127.0.0.1 urchin.lstat.youku.com
127.0.0.1 stat.youku.com
127.0.0.1 xnimg.cn
127.0.0.1 techpowerup.com
127.0.0.1 acs.agent.56.com
127.0.0.1 acs.56.com
127.0.0.1 gug.ku6cdn.com
127.0.0.1 pcs1.app.joy.cn
127.0.0.1 86file.megajoy.com
127.0.0.1 video.gougou.com
127.0.0.1 advstat.xunlei.com
127.0.0.1 dl.xunlei.com
127.0.0.1 i.xunlei.com
127.0.0.1 kkpgv.xunlei.com
127.0.0.1 mtips.xunlei.com
127.0.0.1 pstatic.xunlei.com
127.0.0.1 dynamic.kankan.xunlei.com
127.0.0.1 js.kankan.xunlei.com
127.0.0.1 statis.kankan.xunlei.com
127.0.0.1 biz.sandai.net
127.0.0.1 biz2.sandai.net
127.0.0.1 biz3.sandai.net
127.0.0.1 biz4.sandai.net
127.0.0.1 biz5.sandai.net
127.0.0.1 biz6.sandai.net
127.0.0.1 mediapv.sandai.net
127.0.0.1 mpv.sandai.net
127.0.0.1 mcfg.sandai.net
127.0.0.1 server1.adpolestar.net
127.0.0.1 at-img1.tdimg.com
127.0.0.1 at-img2.tdimg.com
127.0.0.1 at-img3.tdimg.com
127.0.0.1 at-img4.tdimg.com
127.0.0.1 adextensioncontrol.tudou.com
127.0.0.1 adcontrol.tudou.com
127.0.0.1 union.mtime.cn

#土豆
0.0.0.0 *.p2v.tudou.com*
0.0.0.0 at-img1.tdimg.com
0.0.0.0 at-img2.tdimg.com
0.0.0.0 at-img3.tdimg.com
0.0.0.0 adplay.tudou.com
0.0.0.0 adcontrol.tudou.com
0.0.0.0 stat.tudou.com

#酷六
0.0.0.0 v2.stat.ku6.com
0.0.0.0 v3.stat.ku6.com
0.0.0.0 v0.stat.ku6.com
0.0.0.0 v1.stat.ku6.com
0.0.0.0 st.vq.ku6.cn
0.0.0.0 stat2.888.ku6.com
0.0.0.0 pq.stat.ku6.com

#
0.0.0.0 mcfg.sandai.net
0.0.0.0 biz5.sandai.net
0.0.0.0 server1.adpolestar.net
0.0.0.0 advstat.xunlei.com
0.0.0.0 mpv.sandai.net


# google
0.0.0.0 pagead2.googlesyndication.com
0.0.0.0 *.googleadsserving.cn
0.0.0.0 static.googleadsserving.cn
0.0.0.0 googlesyndication.com
0.0.0.0 doubleclick.net
0.0.0.0 googleads.g.doubleclick.net
0.0.0.0 mcfg.sandai.net
0.0.0.0 biz5.sandai.net
0.0.0.0 server1.adpolestar.net
0.0.0.0 advstat.xunlei.com
0.0.0.0 mpv.sandai.net

#google
66.102.7.100 encrypted.google.com
74.125.43.102 encrypted.google.com
74.125.227.4 encrypted.google.com

#56
127.0.0.1 acs.56.com
127.0.0.1 acs.agent.56.com
127.0.0.1 bill.agent.56.com
127.0.0.1 union.56.com
127.0.0.1 v16.56.com

#6间房
127.0.0.1 simba.6.cn
127.0.0.1 pole.6rooms.com
127.0.0.1 shrek.6.cn

#优酷
127.0.0.1 stat.youku.com
127.0.0.1 static.atm.youku.com
127.0.0.1 static.lstat.youku.com
127.0.0.1 valc.atm.youku.com
127.0.0.1 valf.atm.youku.com
127.0.0.1 valo.atm.youku.com
127.0.0.1 valp.atm.youku.com
127.0.0.1 vid.atm.youku.com
127.0.0.1 walp.atm.youku.com

#土豆
127.0.0.1 adextensioncontrol.tudou.com
127.0.0.1 adplay.tudou.com
127.0.0.1 iwstat.tudou.com
127.0.0.1 nstat.tudou.com
127.0.0.1 stat.tudou.com
127.0.0.1 stats.tudou.com

#AD Block End
```

