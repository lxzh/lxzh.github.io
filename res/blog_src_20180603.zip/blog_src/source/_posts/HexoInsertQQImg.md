---
title: Hexo博客正文嵌入QQ表情
date: 2017-02-18 21:26:41
tags: css
---

&ensp; &ensp; &ensp;在迁移以前CSDN的文章到`Hexo`时，发现CSDN文章一个比较好玩的东东就是可以在内容中加入QQ表情，于是想弄到Hexo里面。
# 方案一
&ensp; &ensp; &ensp;一开始想到的做法是把QQ表情下载下来，上传到七牛，然后用`Markdown`插入图片功能插入图片。
<!--more-->
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487431266519.png" width="605"/>
&ensp; &ensp; &ensp;由于`Markdown`插入图片不支持调整图片显示大小，QQ表情图片大于行高，预览的时候就被pass掉。
&ensp; &ensp; &ensp;想到`Markdown`支持原生`html`语法，于是就想用`html`的`img标签`插入图片，调整一下显示大小。编辑预览时发现显示挺正常的，如下图所示：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487425063747.png" width="917"/>
&ensp; &ensp; &ensp;可是在网页里预览却令人大跌眼镜，这是个什么鬼：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487425242052.png" width="112"/>
&ensp; &ensp; &ensp;而且网页里，这个表情点击后还可以弹出来预览，真是画蛇添足。
&ensp; &ensp; &ensp;看了一下生成后网页的源代码，如下：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487425455886.png" width="748"/>
&ensp; &ensp; &ensp;估计是`Fancybox`搞的鬼，它对`html`格式`img标签`做了什么处理吧，这种简单的做法在`Hexo`里不可取，只能另寻方案！
&ensp; &ensp; &ensp;还好以前接触过一点点`css`，稍微懂得一点点，可以用`background:url(xxx)`的方式将图片作为标签文字的背景嵌入，这样表情就不能点击。
# 方案二
&ensp; &ensp; &ensp;首先想到的是`a标签`，于是自定义了几个样式，用于不同的QQ表情，分别引用不同的表情url。*（Hexo主题自定义css样式，见文末）*

```html
#自定义CSS
a.qqangry 	{background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/angry.gif)   	no-repeat center center;background-size:90%;}
a.qqawkward {background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/awkward.gif) 	no-repeat center center;background-size:90%;}
a.qqcry 	{background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/cry.gif)   	no-repeat center center;background-size:90%;}
a.qqcurse 	{background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/curse.gif)   	no-repeat center center;background-size:90%;}
```

```html
#Markdown正文中引入a标签插入表情
生气表情前面的文字<a class="qqangry">&ensp; &ensp;</a>表情后面的文字
哭泣表情前面的文字<a class="qqcry">&ensp; &ensp;</a>表情后面的文字
```
&ensp; &ensp; &ensp;网页预览一下，貌似还可以，如下图：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487428636512.png" width="268"/>
&ensp; &ensp; &ensp;<font color=lightblue> 注：上图中使用了两个空格占位符，不然表情没法显示(PS:没有更好的办法，如有大神，请不吝指导一下)，本文中段落首行缩进也是用了三个空格占位符`&ensp; &ensp; &ensp;`</font>
&ensp; &ensp; &ensp;不过，看着总觉得有点怪怪的，文字下面那一横线看着有点不爽，怎么把它去掉呢？
# 方案三
&ensp; &ensp; &ensp;想到几年前自己复制hao123网址大全自己做了一个个人导航网页，如下每个文字前面的图标，用到的是`i标签`实现的：
<img src="http://o8ydbqznc.bkt.clouddn.com/markdown/1487429276094.png" width="635"/>
&ensp; &ensp; &ensp;于是，尝试将方案二中的`a标签`换成`i标签`，

```html
#自定义CSS
i.qqangry   {background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/angry.gif)       no-repeat center center;background-size:90%;}
i.qqawkward {background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/awkward.gif)     no-repeat center center;background-size:90%;}
i.qqcry     {background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/cry.gif)     no-repeat center center;background-size:90%;}
i.qqcurse   {background:url(http://o8ydbqznc.bkt.clouddn.com/qqimg/curse.gif)       no-repeat center center;background-size:90%;}
```

```html
#Markdown正文中引入i标签插入表情
生气表情前面的文字<i class="qqangry">&ensp; &ensp;</i>表情后面的文字
哭泣表情前面的文字<i class="qqcry">&ensp; &ensp;</i>表情后面的文字
```
&ensp; &ensp; &ensp;效果如下：
生气表情前面的文字<i class="qqangry">&ensp; &ensp;</i>表情后面的文字
哭泣表情前面的文字<i class="qqcry">&ensp; &ensp;</i>表情后面的文字
&ensp; &ensp; &ensp;那讨厌的横线终于没了，大功告成！！！<i class="qqproud">&ensp; &ensp;</i>

# 附一：Hexo主题自定义CSS样式
&ensp; &ensp; &ensp;[<font color=blue>这里</font>](http://blog.csdn.net/captain_magicer/article/details/49073873)有篇文章讲得比较详细，我简单重复啰嗦一下。
&ensp; &ensp; &ensp;本博用的是`Hexo`的`NexT-Mist`主题，找到博客`themes\next\source\css`目录下的`main.styl`文件，在文末加入一行`@import "_myCss/myCss";`，然后在`css`目录下新建一个`_myCss`目录，并新建一个文本文件，保存为`myCss.styl`文件，编辑该文件即可自定义各种css样式啦，祝使用愉快~<i class="qqtongue">&ensp; &ensp;</i>

# 附二：QQ表情排队集合

<i class="qqangry">&ensp; &ensp;</i><i class="qqawkward">&ensp; &ensp;</i><i class="qqbye">&ensp; &ensp;</i><i class="qqcrazy">&ensp; &ensp;</i><i class="qqcry">&ensp; &ensp;</i><i class="qqcurse">&ensp; &ensp;</i><i class="qqcute">&ensp; &ensp;</i><i class="qqdespise">&ensp; &ensp;</i><i class="qqdoubt">&ensp; &ensp;</i><i class="qqenvy">&ensp; &ensp;</i><i class="qqfastcry">&ensp; &ensp;</i><i class="qqknock">&ensp; &ensp;</i><i class="qqlaugh">&ensp; &ensp;</i><i class="qqmad">&ensp; &ensp;</i><i class="qqohmy">&ensp; &ensp;</i><i class="qqpanic">&ensp; &ensp;</i><i class="qqproud">&ensp; &ensp;</i><i class="qqquiet">&ensp; &ensp;</i><i class="qqsad">&ensp; &ensp;</i><i class="qqshutup">&ensp; &ensp;</i><i class="qqshy">&ensp; &ensp;</i><i class="qqsleep">&ensp; &ensp;</i><i class="qqsmile">&ensp; &ensp;</i><i class="qqstruggle">&ensp; &ensp;</i><i class="qqtitter">&ensp; &ensp;</i><i class="qqtongue">&ensp; &ensp;</i><i class="qqwail">&ensp; &ensp;</i><i class="qqwronged">&ensp; &ensp;</i>





