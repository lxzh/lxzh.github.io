---
title: Csharp PPT Operator
date: 2015-07-24 23:56:40
tags:
---

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Core;
using PPT = Microsoft.Office.Interop.PowerPoint;
using System.Windows;
using System.Collections;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using Tools.functionModel.file;
using System.Drawing;
using System.Drawing.Imaging;
//using System.Windows.Controls;
 
namespace Tools.baseModel.common {
    /// <summary>
    /// PPT文档操作实现类.
    /// </summary>
    public class pptBase {
        private string temPath = "";
        private string pptPath = "";
        #region=========基本的参数信息=======
        PPT.Application pptApp;                 //PPT应用程序变量
 
        public PPT.Application PptApp {
            get { return pptApp; }
            set { pptApp = value; }
        }
        PPT.Presentation pptDoc;                //PPT文档变量
        PPT.Slides pptSlides = null;
        PPT.Slide pptSlide = null;
        private int pageCount=0;
        #endregion
 
        public PPT.Shapes Shapes {
            get { return pptSlide.Shapes; }
        }
 
 
        public pptBase(string path) {
            this.temPath = commonPath.fiberFolder + "/other/template.pot";
            this.pptPath = path;
            //如果已存在，则删除
            if (File.Exists((string)pptPath)) {
                File.Delete((string)pptPath);
            }
            FileInfo file = new FileInfo(this.temPath);
            pptApp = new PPT.Application();    //初始化
            pptApp.Visible = MsoTriState.msoTrue;
            pptDoc = pptApp.Presentations.Open(file.FullName, MsoTriState.msoFalse, MsoTriState.msoTrue, MsoTriState.msoTrue);
            pptSlides = pptDoc.Slides;
            //pptDoc = pptApp.Presentations.Add(Microsoft.Office.Core.MsoTriState.msoFalse);
        }
 
        public void AddPage() {
            pageCount++;
            //pptDoc.Slides.Add(pageCount, PPT.PpSlideLayout.ppLayoutText);
            pptSlide = pptSlides.Add(pageCount, PPT.PpSlideLayout.ppLayoutTitleOnly);
        }
 
        public void InsertPage(int index) {
            PPT.CustomLayout ppLayout = pptSlide.CustomLayout;
            pptSlide = pptSlides.AddSlide(index, ppLayout);
            pageCount++;
        }
 
 
        #region 添加文本框
        public PPT.Shape drawText(PPT.Shapes shapes, pptText textBox) {
            PPT.Shape shape = null;
            if (textBox == null || textBox.Location.IsEmpty || textBox.FrameSize.IsEmpty)
                return shape;
            shape = shapes.AddTextbox(textBox.Orientation, textBox.X, textBox.Y, textBox.Width, textBox.Height);
            shape.TextFrame.HorizontalAnchor = textBox.HorizontalAnchor;
            shape.TextFrame.VerticalAnchor = textBox.VerticalAnchor;
            shape.TextFrame.TextRange.Font.Color.RGB = colorFormat(textBox.ForeColor);
            shape.TextFrame.TextRange.Font.Bold = textBox.Font.Bold ? MsoTriState.msoTrue : MsoTriState.msoFalse;
            shape.TextFrame.TextRange.Font.Italic = textBox.Font.Italic ? MsoTriState.msoTrue : MsoTriState.msoFalse;
            shape.TextFrame.TextRange.Font.Underline = textBox.Font.Underline ? MsoTriState.msoTrue : MsoTriState.msoFalse;
            shape.TextFrame.TextRange.Font.Size = textBox.Font.Size;
            shape.TextFrame.TextRange.Font.Name = textBox.Font.Name;
            shape.TextFrame.MarginLeft = 0;
            shape.TextFrame.MarginRight = 0;
            if (textBox.BackColor == Color.Transparent) {
                shape.Fill.Visible = Microsoft.Office.Core.MsoTriState.msoFalse;
            } else {
                shape.Fill.BackColor.RGB = colorFormat(textBox.BackColor);
            }
            shape.Line.Weight = textBox.BoardWeight;
            if (textBox.BoardColor == Color.Transparent) {
                shape.Line.Visible = Microsoft.Office.Core.MsoTriState.msoFalse;
            } else {
                shape.Line.BackColor.RGB = colorFormat(textBox.BoardColor);
            }
            shape.Line.DashStyle = textBox.BoardStyle;
            shape.TextFrame.TextRange.Text = textBox.Text;
            return shape;
        }
        #endregion 
 
        #region 添加基本图形
        //画直线
        public PPT.Shape drawLine(PPT.Shapes shapes, float beginX, float beginY, float endX, float endY) {
            PPT.Shape shape = shapes.AddLine(beginX, beginY, endX, endY);
            return shape;
        }
        //画直线
        public PPT.Shape drawLine(PPT.Shapes shapes, float beginX, float beginY, float endX, float endY, float weight, Color foreColor) {
            PPT.Shape shape = shapes.AddLine(beginX, beginY, endX, endY);
            shape.Line.ForeColor.RGB = colorFormat(foreColor);  //线条颜色
            shape.Line.Weight = weight;                         //线条粗细
            return shape;
        }
        //画矩形
        public PPT.Shape drawRectangle(PPT.Shapes shapes, float beginX, float beginY, float width, float height) {
            PPT.Shape shape = shapes.AddShape(MsoAutoShapeType.msoShapeRectangle, beginX, beginY, width, height);
            return shape;
        }
        //画矩形
        public PPT.Shape drawRectangle(PPT.Shapes shapes, float beginX, float beginY, float width, float height, float weight, Color foreColor, Color backColor) {
            PPT.Shape shape = shapes.AddShape(MsoAutoShapeType.msoShapeRectangle, beginX, beginY, width, height);
            shape.Line.ForeColor.RGB = colorFormat(foreColor);  //线条颜色
            shape.Fill.BackColor.RGB = colorFormat(backColor);  //填充颜色
            shape.Line.Weight = weight;                         //线条粗细
            return shape;
        }
        //画箭头
        public PPT.Shape drawArrow(PPT.Shapes shapes, float beginX, float beginY, float endX, float endY,float weight) {
            float width=(float)Math.Sqrt(Math.Pow(endX-beginX,2)+Math.Pow(endY-beginY,2));
            float startX = (beginX + endX) / 2-width/2;
            float startY = (beginY + endY) / 2;
            float angle = endX==beginX?(endY>beginY?90:-90):(float)Math.Atan((endY – beginY) / (endX – beginX));
            angle = (float)(angle / Math.PI * 180.0);
            angle = angle < 0 ? 180.0f + angle : angle;
            PPT.Shape shape = shapes.AddShape(MsoAutoShapeType.msoShapeRightArrow, startX, startY, width, weight);
            shape.Rotation = angle;
            return shape;
        }
        //画箭头
        public PPT.Shape drawRightArrow(PPT.Shapes shapes, float beginX, float beginY, float endX, float endY, float weight, Color foreColor, Color backColor) {
            PPT.Shape shape = drawArrow(shapes, beginX, beginY, endX, endY, weight);
            shape.Line.ForeColor.RGB = colorFormat(foreColor);  //线条颜色
            shape.Fill.BackColor.RGB = colorFormat(backColor);  //填充颜色
            return shape;
        }
        #endregion
 
        #region 添加图片
        public PPT.Shape AddPicture(PPT.Shapes shapes, string picPath, float beginX, float beginY, float width, float height) {
            PPT.Shape shape = null;
            if (!File.Exists(picPath)) {
                throw new Exception("图片文件不存在!");
            } else {
                shape = shapes.AddPicture(picPath, MsoTriState.msoFalse, MsoTriState.msoTrue, beginX, beginY, width, height);
            }
            return shape;
        }
        public PPT.Shape AddPicture(PPT.Shapes shapes, Bitmap bitmap, float beginX, float beginY, float width, float height) {
            PPT.Shape shape = null;
            string picPath=System.IO.Path.GetTempPath()+"bitmap.bmp";
            bitmap.Save(picPath, ImageFormat.Bmp);
            shape = shapes.AddPicture(picPath, MsoTriState.msoFalse, MsoTriState.msoTrue, beginX, beginY, width, height);
            return shape;
        }
        #endregion 
 
        public void Close() {
            try {
                //WdSaveFormat为PPT文档的保存格式
                PPT.PpSaveAsFileType format = PPT.PpSaveAsFileType.ppSaveAsDefault;
                //将pptDoc文档对象的内容保存为PPT文档
                pptDoc.SaveAs(pptPath, format, Microsoft.Office.Core.MsoTriState.msoFalse);
 
                //关闭pptDoc文档对象
                pptDoc.Close();
                //关闭pptApp组件对象
                pptApp.Quit();
            } catch (Exception ex) {
                outPrint.appendText("保存或关闭PPT出错，错误信息：" + ex.Message);
            }
        }
        /// <summary>
        /// 系统颜色转换为PPT支持的颜色值
        /// </summary>
        private int colorFormat(System.Drawing.Color color) {
            int value = ((color.B * 256 + color.G) * 256) + color.R;//Office RGB与 System.Drawing.Color.RGB顺序相反
            return value;
        }
    }
}
```

