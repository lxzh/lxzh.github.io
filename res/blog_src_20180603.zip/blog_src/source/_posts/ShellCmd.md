---
title: ShellCmd
date: 2017-01-08 13:34:07
tags: Shell
---
Mac shell小技巧

	COUNT=0;dir=$(eval pwd); for name in $(ls $dir);do COUNT=$(($COUNT+1));param=$(eval printf "%03d" $COUNT);mv $name frame$param.png; done
将当前目录下所有图片文件按顺序格式化递增序号重命名
输出文件格式：`xxx%03d.png`
**说明：**
`$(eval pwd)`：获取当前目录
`for name in $(ls $dir)`：遍历当前目录下所以文件
`COUNT=$(($COUNT+1))`：计数器+1
`param=$(eval printf "%03d" $COUNT)`：计数器三位前向补零格式化
`mv $name frame$param.png`：文件重命名

