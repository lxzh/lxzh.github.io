---
title: 基础数据结构(一)——冒泡排序
date: 2013-09-25 16:29:20
tags: data structure
---

&ensp; &ensp; &ensp; 最近为了准备找工作，数据结构这块必须得恶补。
&ensp; &ensp; &ensp; 首先，一个很基础的东东就是基础排序算法和查找算法了。

&ensp; &ensp; &ensp; 这里，先说说排序吧。
&ensp; &ensp; &ensp; 为了做好准备工作，在此先弄一个数组生成器吧，把它封装为一个类，同时也为了后续其他的测试提供方便，免得拷贝过来拷贝过去。
<!--more-->
&ensp; &ensp; &ensp; 一个简单的数组类：

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace BasicStructure
{
    class CSharpArray
    {
        private int[] array;
        public void CSharpArray(int count)
        {
            array = new int[count];
            Random random = new Random();
            for (int i = 0; i < count; i++)
            {
                array[i] = random.Next(count);
            }
        }
        public int[] getArray()
        {
            return array;
        }
        public void PrintArray(int []array)
        {
            int count=array.Length;
            for (int i = 0; i < count; i++)
            {
                Console.Write("\t{0}", array[i]);
                if ((i + 1) % 8 == 0)
                    Console.WriteLine();
            }
        }
    }
}
```
&ensp; &ensp; &ensp; 第一个要说的排序算法当属[<font color=blue>冒泡排序算法</font>](http://student.zjzk.cn/course_ware/data_structure/web/paixu/paixu8.3.1.1.htm)了，链接里有比较详细的介绍，在此就不罗嗦了。
&ensp; &ensp; &ensp; 冒泡排序的基本实现如下：

```cs
public void BubbleSort(int []array)
{
  int temp;
  int count = array.Length;
  for(int i=count;i>=1 ;i--)
  {
      for (int j = 0; j < i - 1; j++)
      {
          if (array[j] > array[j + 1])
          {
              temp = array[j];
              array[j] = array[j + 1];
              array[j + 1] = temp;
          }
      }
  }
}
```
&ensp; &ensp; &ensp; 测试如下:

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace BasicStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            CSharpArray csharArray = new CSharpArray(100);
            int[] array = csharArray.getArray();
            Console.WriteLine("排序前:");
            Console.WriteLine();
            csharArray.PrintArray(array);
            Console.WriteLine();
            Console.WriteLine("排序后:");
            csharArray.BubbleSort(array);
            csharArray.PrintArray(array);
            Console.ReadKey();
        }
    }
}
```
&ensp; &ensp; &ensp; 为了展示一下它的实现原理，这里需要稍微修改一下冒泡排序方法，同时得减少一点数据，以便于对比观察。

```cs
public void BubbleSort(int []array)
{
  int temp;
  int count = array.Length;
  for(int i=count;i>=1 ;i--)
  {
      for (int j = 0; j < i - 1; j++)
      {                  
          if (array[j] > array[j + 1])
          {
              temp = array[j];
              array[j] = array[j + 1];
              array[j + 1] = temp;
          }
      }
      PrintArray(array);
  }
} 
```
&ensp; &ensp; &ensp; 以下为输出结果：
&ensp; &ensp; &ensp; 排序前:

        1       7       7       0       5       2       1       3

&ensp; &ensp; &ensp; 排序后:

        1       7       0       5       2       1       3       7
        1       0       5       2       1       3       7       7
        0       1       2       1       3       5       7       7
        0       1       1       2       3       5       7       7
        0       1       1       2       3       5       7       7
        0       1       1       2       3       5       7       7
        0       1       1       2       3       5       7       7
        0       1       1       2       3       5       7       7
        0       1       1       2       3       5       7       7

&ensp; &ensp; &ensp; 右上可以看到，每一轮排序，每行都会有个数字由前向后想冒泡一样移动，因此这种排序正是得名于像“气泡一样”从序列的一段浮动到另一端。

&ensp; &ensp; &ensp; 以上为升序排序，若采用降序排序，则只需稍微改动一点点，即将`BubbleSort`方法中的**“>”**号改为**“<”**即可。

&ensp; &ensp; &ensp; 好了，本篇到此结束！

<span><a>反馈请点击:</a><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&amp;email=lKWmp62soKykoqLU5eW69-v5" style="text-decoration:none"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png" alt="" /></a></span>

