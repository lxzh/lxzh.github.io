---
title: 基础排序算法(三)——对半插入排序
date: 2014-04-19 12:20:52
tags: data structure
---
&ensp; &ensp; &ensp; 之前的文章介绍了[<font color=blue>冒泡排序</font>](http://blog.lxzh123.com/2013/09/25/Basic-Sort-Algorithm-BubbleSort/)和[<font color=blue>插入排序</font>](http://blog.lxzh123.com/2013/09/30/Basic-Sort-Algorithm-InsertionSort/)，这里再补充一个`对半插入排序`算法，它与`对半查找算法`（`二分查找算法`）有点相似之处。

&ensp; &ensp; &ensp; 还是先上代码：
<!--more-->

```cs
   public void HalfInsertSort(int[] array)
   {
       int j = 0, temp, low, high, mid;
       int count = array.Length;
       for (int i = 1; i < count; i++)
       {
           temp = array[i];
           low = 0;
           high = i - 1;
           while (low <= high)
           {
               mid = (low + high) / 2;
               if (temp < array[mid]) high = mid - 1;
               else low = mid + 1;
           }
           for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
           array[low] = temp;
       }
   }
```
&ensp; &ensp; &ensp; 在`Program`的`Main`函数里New一个[<font color=blue>（一）</font>](http://blog.lxzh123.com/2013/09/25/Basic-Sort-Algorithm-BubbleSort/)中写的那个`CSharpArray`类，调用其中的方法测试：

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            CSharpArray csharArray = new CSharpArray(8);
            int[] array = csharArray.getArray();
            Console.WriteLine("排序前:");
            Console.WriteLine();
            csharArray.PrintArray(array);
            Console.WriteLine();
            Console.WriteLine("排序后:");
            csharArray.HalfInsertSort(array);
            csharArray.PrintArray(array);

            Console.ReadKey();
        }
    }
}
```
&ensp; &ensp; &ensp; 输出结果：
&ensp; &ensp; &ensp; 排序前:
       
        1       0       2       5       4       1       3       4
&ensp; &ensp; &ensp; 排序后:
       
        0       1       1       2       3       4       4       5
&ensp; &ensp; &ensp; 为了显示`for`循环中的每次执行结果，在`HalfInsertSort`方法里加一句输出：

```cs
   public void HalfInsertSort(int[] array)
   {
       int j = 0, temp, low, high, mid;
       int count = array.Length;
       for (int i = 1; i < count; i++)
       {
           temp = array[i];
           low = 0;
           high = i - 1;
           while (low <= high)
           {
               mid = (low + high) / 2;
               if (temp < array[mid]) high = mid - 1;
               else low = mid + 1;
           }
           for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
           array[low] = temp;
           PrintArray(array);
       }
   }
```
&ensp; &ensp; &ensp; 再次编译运行即得以下结果：
&ensp; &ensp; &ensp; 排序前:
       
        1       0       2       5       4       1       3       4
&ensp; &ensp; &ensp; 排序后:

        0       1       2       5       4       1       3       4
        0       1       2       5       4       1       3       4
        0       1       2       5       4       1       3       4
        0       1       2       4       5       1       3       4
        0       1       1       2       4       5       3       4
        0       1       1       2       3       4       5       4
        0       1       1       2       3       4       4       5
        0       1       1       2       3       4       4       5
&ensp; &ensp; &ensp; 从输出结果可以看出，遍历数组元素，利用对半查找原理找到其位置，插入，将受影响的元素一次前移。

&ensp; &ensp; &ensp; 同样，为了将以上的升序排序算法改为降序，也只需将`while`括号里的大于号改为小于号即可。

&ensp; &ensp; &ensp; 这里，既然将其封装在一个类里，自然要提高其通用性，因此，我可以再给改排序算法添加一个参数，用来标记是升序排序还是降序排序。如：用**“0”**表示**升序**，用**“1”**表示**降序**，在不降低代码运行效率时以牺牲代码简洁性来修改一下代码：

```cs
public void HalfInsertSort(int[] array, int orderType)
{
   int j = 0, temp,low,high,mid;
   int count = array.Length;
   if (orderType == 0)
   {
      for (int i = 1; i < count; i++)
      {
          temp = array[i];
          low = 0;
          high = i - 1;
          while (low <= high)
          {
              mid = (low + high) / 2;
              if (temp < array[mid]) high = mid - 1;
              else low = mid + 1;
          }
          for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
          array[low] = temp;
          PrintArray(array);
      }
   }
   else if (orderType == 1)
   {
      for (int i = 1; i < count; i++)
      {
          temp = array[i];
          low = 0;
          high = i - 1;
          while (low < high)
          {
              mid = (low + high) / 2;
              if (temp > array[mid]) high = mid - 1;
              else low = mid + 1;
          }
          for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
          array[low] = temp;
          PrintArray(array);
      }
   }
}
```
&ensp; &ensp; &ensp; 再修改`Main`函数里代码：

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            CSharpArray csharArray = new CSharpArray(8);
            int[] array = csharArray.getArray();
            Console.WriteLine("排序前:");
            Console.WriteLine();
            csharArray.PrintArray(array);
            Console.WriteLine();
            Console.WriteLine("升序排序后:");
            csharArray.HalfInsertSort(array, 0);
            csharArray.PrintArray(array);
            Console.WriteLine("降序排序后:");
            csharArray.HalfInsertSort(array, 1);
            csharArray.PrintArray(array);

            Console.ReadKey();
        }
    }
}
```
&ensp; &ensp; &ensp; 编译运行结果如下所示：
&ensp; &ensp; &ensp; 排序前:

        2       4       0       3       5       6       1       1
&ensp; &ensp; &ensp; 升序排序后:

        2       4       0       3       5       6       1       1
        0       2       4       3       5       6       1       1
        0       2       3       4       5       6       1       1
        0       2       3       4       5       6       1       1
        0       2       3       4       5       6       1       1
        0       1       2       3       4       5       6       1
        0       1       1       2       3       4       5       6
        0       1       1       2       3       4       5       6
&ensp; &ensp; &ensp; 降序排序后:

        1       0       1       2       3       4       5       6
        1       1       0       2       3       4       5       6
        2       1       1       0       3       4       5       6
        3       2       1       1       0       4       5       6
        4       3       2       1       1       0       5       6
        5       4       3       2       1       1       0       6
        6       5       4       3       2       1       1       0
        6       5       4       3       2       1       1       0

&ensp; &ensp; &ensp; 最后，再次贴一下`CSharpArray`类的代码：

```cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BasicStructure
{
    class CSharpArray
    {
        private int[] array;
        public CSharpArray(int count)
        {
            array = new int[count];
            Random random = new Random();
            for (int i = 0; i < count; i++)
            {
                array[i] = random.Next(count);
            }
        }
        public int[] getArray()
        {
            return array;
        }
        public void PrintArray(int []array)
        {
            int count=array.Length;
            for (int i = 0; i < count; i++)
            {
                Console.Write("\t{0}", array[i]);
                if ((i + 1) % 8 == 0)
                    Console.WriteLine();
            }
        }
        /// <summary>
        /// 冒泡排序算法
        /// </summary>
        /// <param name="array">待排序的数组</param>
        /// <param name="orderType">排序类型 0：升序；1：降序</param>
        public void BubbleSort(int []array,int orderType)
        {
            int temp;
            int count = array.Length;
            if(orderType==0)
            {
                for (int i = count; i >= 1; i--)
                {
                    for (int j = 0; j < i - 1; j++)
                    {
                        if (array[j] > array[j + 1])
                        {
                            temp = array[j];
                            array[j] = array[j + 1];
                            array[j + 1] = temp;
                        }
                    }
                    PrintArray(array);
                }
            }else if(orderType==1)
            {
                for (int i = count; i >= 1; i--)
                {
                    for (int j = 0; j < i - 1; j++)
                    {
                        if (array[j] < array[j + 1])
                        {
                            temp = array[j];
                            array[j] = array[j + 1];
                            array[j + 1] = temp;
                        }
                    }
                    PrintArray(array);
                }
            }
        }

        /// <summary>
        /// 插入排序算法
        /// </summary>
        /// <param name="array">待排序的数组</param>
        /// <param name="orderType">排序类型 0：升序；1：降序</param>
        public void InsertSort(int[] array,int orderType)
        {
            int j = 0,temp;
            int count = array.Length;
            if (orderType == 0)
            {
                for (int i = 1; i < count; i++)
                {
                    temp = array[i];
                    j = i;
                    while (j > 0 && array[j - 1] >= temp)
                    {
                        array[j] = array[j - 1];
                        j -= 1;
                    }
                    array[j] = temp;
                    PrintArray(array);
                }
            }
            else if (orderType == 1)
            {
                for (int i = 1; i < count; i++)
                {
                    temp = array[i];
                    j = i;
                    while (j > 0 && array[j - 1] <= temp)
                    {
                        array[j] = array[j - 1];
                        j -= 1;
                    }
                    array[j] = temp;
                    PrintArray(array);
                }
            }
        }

        /// <summary>
        /// 对半插入排序算法
        /// </summary>
        /// <param name="array">待排序的数组</param>
        /// <param name="orderType">排序类型 0：升序；1：降序</param>
        public void HalfInsertSort(int[] array, int orderType)
        {
            int j = 0, temp,low,high,mid;
            int count = array.Length;
            if (orderType == 0)
            {
                for (int i = 1; i < count; i++)
                {
                    temp = array[i];
                    low = 0;
                    high = i - 1;
                    while (low <= high)
                    {
                        mid = (low + high) / 2;
                        if (temp < array[mid]) high = mid - 1;
                        else low = mid + 1;
                    }
                    for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
                    array[low] = temp;
                    PrintArray(array);
                }
            }
            else if (orderType == 1)
            {
                for (int i = 1; i < count; i++)
                {
                    temp = array[i];
                    low = 0;
                    high = i - 1;
                    while (low < high)
                    {
                        mid = (low + high) / 2;
                        if (temp > array[mid]) high = mid - 1;
                        else low = mid + 1;
                    }
                    for (j = i - 1; j >= low; j--) array[j + 1] = array[j];
                    array[low] = temp;
                    PrintArray(array);
                }
            }
        }
    }
}
```
&ensp; &ensp; &ensp; OK，对半插入排序算法的基本演示就到此结束！


&ensp; &ensp; &ensp; 注：由于数组时代码里生成的随机数组，因此每次运行的结果基本不一样，可能与以上演示结果不同。


<span><a>反馈请点击:</a><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&amp;email=lKWmp62soKykoqLU5eW69-v5" style="text-decoration:none"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png" alt="" /></a></span>

