---
title: Half Precision float
date: 2017-12-09 00:22:44
tags:
mathjax: true
---

Half-precision floating-point format
===
	bit15:         1 bit SIGN      +---+-------+--------------+
	bit14-10:      5 bit EXP       | S | EEEEE | MM MMMM MMMM |
	bit0-9:       10 bit MAN       +---+-------+--------------+

> 参考 IEEE754-2008 WIKIPEDIA:[Half-precision floating-point format](https://en.wikipedia.org/wiki/Half-precision_floating-point_format) 

Hall-precision floating-point number 半精度浮点数，文中简称`fp16`

# 1.计算公式

## Denormal number: 
E=`00000`   $ y=(-1)^S\times \frac{M}{2^{10}} \times 2^{-14}$ 

## Normal number: 
E=`00001`~`11110`   $y=(-1)^S\times(1+\frac{M}{2^{10}}) \times 2^{E-15}$


## Inf：Infinity 
E=`11111` M=`00000 00000`

## NaN: Not a number 
E=`11111` M>0

<!--more-->

# 2.小数转fp16

例如：9.125
   
## 1) 转换为二进制表示

9->`1001`         $2^3+1$
0.125->`0.001`  $2^{-3}$
9.125->`1001.001`
   
## 2) 转换为二进制科学计数法
   
`1001.001`->$1.001001\times2^3$
   
## 3) 标准化
fp16总共`16bit`，其中尾数`10bit`，由于任何一个数(0除外)转换为`二进制科学计数法`后，整数部分一定是`1`，所以该bit可以不表示，及`隐藏1个bit`，用10bit尾数表示小数部分

因此将小数部分(尾数)补齐到10bit为：`00100 10000` 

fp16中指数位占`5bit`，可以表示`0~31`，为了让fp16既能表示整数，也能表示小数，我们给指数E加一个`bias=15`，将`-15~16`扩充到`0~31`

所以3+15=18：`10010`

指数占`1bit`，用`0表示整数`，`1表示负数`

综上：
`9.125`表示为fp16对应的二进制值为：`0` `10010` `00100 10000`

## 4) 公式还原

符号：S=`0`
指数：E=`b10010`=18
尾数：M=`b00100 10000`=144
浮点数值：$y=(-1)^0\times(1+\frac{144}{2^{10}})\times2^{18-15}=1.140625\times8=9.125$


